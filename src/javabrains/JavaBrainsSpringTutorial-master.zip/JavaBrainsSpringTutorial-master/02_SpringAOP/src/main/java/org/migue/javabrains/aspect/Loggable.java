/**
 * 
 */
package org.migue.javabrains.aspect;

/**
 * @author migue
 *
 */
public @interface Loggable {

}
