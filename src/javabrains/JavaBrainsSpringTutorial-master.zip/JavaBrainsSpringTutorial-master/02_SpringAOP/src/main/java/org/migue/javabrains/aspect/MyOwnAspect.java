/**
 * 
 */
package org.migue.javabrains.aspect;

/**
 * @author migue
 * this is a primitive own implementation of an aspect...
 */
public class MyOwnAspect {
	
	
	public void loggingAdvice() {
		System.out.println("Logging from the advice");
	}
}
